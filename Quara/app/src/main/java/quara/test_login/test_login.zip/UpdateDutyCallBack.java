package quara.test_login;

/**
 * Created by ylin9 on 2/28/2016.
 */
interface UpdateDutyCallBack {
    public abstract void done(String ta_info);
}