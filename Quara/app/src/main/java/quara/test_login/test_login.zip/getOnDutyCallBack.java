package quara.test_login;

/**
 * Created by ylin9 on 2/28/2016.
 */
interface getOnDutyCallBack {
    public abstract void done(String[] ta_list);
}
