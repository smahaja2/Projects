package quara.test_login;

/**
 * Created by ylin9 on 3/24/2016.
 */
public class Queue {
    String course_name;
    String queue_name;

    public Queue(String course_name, String queue_name)
    {
        this.course_name = course_name;
        this.queue_name = queue_name;
    }

}
