package quara.test_login;

import java.util.ArrayList;
import java.util.Map;

/**
 * Created by ylin9 on 4/7/2016.
 */
interface GetActualQueueCallBack {
    public abstract void done(ArrayList queue);
}
