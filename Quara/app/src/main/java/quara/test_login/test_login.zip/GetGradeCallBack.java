package quara.test_login;

import java.util.ArrayList;
import java.util.Map;

interface GetGradeCallBack {
    public abstract void done(ArrayList returnGrade);
}

