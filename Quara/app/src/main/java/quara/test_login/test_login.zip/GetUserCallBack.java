package quara.test_login;


interface GetUserCallBack {

    public abstract void done(User returnUser);

}
