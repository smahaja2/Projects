package quara.test_login;

/**
 * Created by ylin9 on 2/24/2016.
 */
public class TA {
    String name, course_name;

    public TA(String name, String course_name)
    {
        this.name = name;
        this.course_name = course_name;
    }

}
