package quara.test_login;

import java.util.Map;

/**
 * Created by ylin9 on 2/24/2016.
 */
interface CheckAuthorisationCallBack {
    public abstract void done(String ta_info);
}
