package quara.test_login;

public interface GetRegIdCallBack {
    public abstract void done(String regId);
}
