package quara.test_login;

import java.util.ArrayList;
import java.util.Map;

/**
 * Created by ylin9 on 2/10/2016.
 */
interface GetQueueCallBack {
    public abstract void done(ArrayList returnQueue);
}

