package quara.test_login;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by ylin9 on 2/6/2016.
 */
interface GetCourseCallBack {
    public abstract void done(Map returnCourse);
}
