package quara.test_login;

import java.util.ArrayList;

/**
 * Created by ylin9 on 4/7/2016.
 */
interface SendTALogInCallBack {
    public abstract void done(String str);
}
